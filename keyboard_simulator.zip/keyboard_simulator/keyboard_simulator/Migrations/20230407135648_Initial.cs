﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace keyboard_simulator.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Progress",
                columns: table => new
                {
                    id_progress = table.Column<int>(type: "integer", nullable: false),
                    date_progress = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    time_progress = table.Column<int>(type: "integer", nullable: false),
                    mistakes = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Progress");
        }
    }
}
