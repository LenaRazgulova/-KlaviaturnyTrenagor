﻿namespace keyboard_simulator
{
    partial class FormLevel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelLevel1 = new Panel();
            title = new Label();
            label2 = new Label();
            labelTimer = new Label();
            labelError = new Label();
            label1 = new Label();
            button1 = new Button();
            button3 = new Button();
            textLevel1 = new TextBox();
            answerLevel1 = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            panelLevel1.SuspendLayout();
            SuspendLayout();
            // 
            // panelLevel1
            // 
            panelLevel1.BackColor = Color.FromArgb(128, 255, 128);
            panelLevel1.Controls.Add(title);
            panelLevel1.Controls.Add(label2);
            panelLevel1.Controls.Add(labelTimer);
            panelLevel1.Controls.Add(labelError);
            panelLevel1.Controls.Add(label1);
            panelLevel1.Controls.Add(button1);
            panelLevel1.Controls.Add(button3);
            panelLevel1.Controls.Add(textLevel1);
            panelLevel1.Controls.Add(answerLevel1);
            panelLevel1.Dock = DockStyle.Fill;
            panelLevel1.Location = new Point(0, 0);
            panelLevel1.Name = "panelLevel1";
            panelLevel1.Size = new Size(1049, 224);
            panelLevel1.TabIndex = 6;
            // 
            // title
            // 
            title.AutoSize = true;
            title.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            title.ForeColor = Color.DeepPink;
            title.Location = new Point(126, 18);
            title.Name = "title";
            title.Size = new Size(131, 38);
            title.TabIndex = 14;
            title.Text = "Уровень";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.ForeColor = Color.HotPink;
            label2.Location = new Point(676, 46);
            label2.Name = "label2";
            label2.Size = new Size(58, 20);
            label2.TabIndex = 13;
            label2.Text = "Время:";
            // 
            // labelTimer
            // 
            labelTimer.AutoSize = true;
            labelTimer.Location = new Point(736, 46);
            labelTimer.Name = "labelTimer";
            labelTimer.Size = new Size(17, 20);
            labelTimer.TabIndex = 12;
            labelTimer.Text = "0";
            // 
            // labelError
            // 
            labelError.AutoSize = true;
            labelError.Location = new Point(430, 46);
            labelError.Name = "labelError";
            labelError.Size = new Size(17, 20);
            labelError.TabIndex = 11;
            labelError.Text = "0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = Color.HotPink;
            label1.Location = new Point(270, 46);
            label1.Name = "label1";
            label1.Size = new Size(158, 20);
            label1.TabIndex = 10;
            label1.Text = "Количество ошибок:";
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.HotPink;
            button1.Location = new Point(818, 62);
            button1.Name = "button1";
            button1.Size = new Size(114, 46);
            button1.TabIndex = 8;
            button1.Text = " Старт";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Lime;
            button3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.HotPink;
            button3.Location = new Point(126, 67);
            button3.Name = "button3";
            button3.Size = new Size(114, 46);
            button3.TabIndex = 7;
            button3.Text = "Назад";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // textLevel1
            // 
            textLevel1.Location = new Point(270, 76);
            textLevel1.Name = "textLevel1";
            textLevel1.ReadOnly = true;
            textLevel1.Size = new Size(517, 27);
            textLevel1.TabIndex = 1;
            // 
            // answerLevel1
            // 
            answerLevel1.Location = new Point(126, 150);
            answerLevel1.Name = "answerLevel1";
            answerLevel1.Size = new Size(806, 27);
            answerLevel1.TabIndex = 0;
            answerLevel1.TextChanged += answerLevel1_TextChanged;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // FormLevel
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1049, 224);
            Controls.Add(panelLevel1);
            KeyPreview = true;
            Name = "FormLevel";
            Text = "Форма уровней";
            KeyDown += Form2_KeyDown;
            panelLevel1.ResumeLayout(false);
            panelLevel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button button3;
        private TextBox textLevel1;
        private TextBox answerLevel1;
        private Button button1;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private Label labelError;
        private Label label2;
        private Label labelTimer;
        public Label title;
        public Panel panelLevel1;
    }
}