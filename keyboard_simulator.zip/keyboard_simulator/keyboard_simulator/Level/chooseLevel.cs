namespace keyboard_simulator
{
    public partial class chooseLevel : Form
    {
        progress form_p = new progress();
        public string ur = "";
        public chooseLevel()
        {

            InitializeComponent();
        }
        private void ButtonLevel1_Click(object sender, EventArgs e)
        {
            Level1 form2 = new Level1();
            form2.Show();

        }

        private void ButtonLevel2_Click(object sender, EventArgs e)
        {
            Level2 form3 = new Level2();
            form3.Show();
        }

        private void ButtonLevel3_Click(object sender, EventArgs e)
        {
            Level3 form4 = new Level3();
            form4.Show();
        }

        private void resultat_Click(object sender, EventArgs e)
        {
            progress form_p = new progress();
            form_p.Show();
        }

    }
}