﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace keyboard_simulator
{
    public partial class Level2 : keyboard_simulator.FormLevel
    {
        public Level2()
        {
            InitializeComponent();
            str1 = new String[12]
            {
            "кк гг кк гг",
            "гкгк ккгг ккгк гкгк",
            "кгкк кгкг ккгк кггк",
            "выыд дкыг кака кокк",
            "ажгв ггдп гкко лыкг",
            "гкжк когк каык гкрд",
            "уу шш уу шш",
            "ушуш ушуу ушуу шшуу",
            "ушуу ушуу шушш уушу",
            "фжуш двшу рлук пшшп",
            "шшфш пшшр ршпф шужа",
            "жгшк вушу шдоу оуаш"
            };

        }
        private void Уровень2_Load(object sender, EventArgs e)
        {
        }

    }
}
