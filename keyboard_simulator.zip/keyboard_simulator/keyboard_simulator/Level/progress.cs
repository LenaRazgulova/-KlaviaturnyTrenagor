﻿using keyboard_simulator.Model;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace keyboard_simulator
{
    public partial class progress : Form
    {
        public progress()
        {
            InitializeComponent();

        }
        private void LoadData()
        {
            using (ProgressContext db = new ProgressContext())
            {
                var progress = db.Progress.ToList();
                foreach (var item in progress)
                {
                    dataGridView1.Rows.Add(item.ur, item.time_progress, item.mistakes);
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {


            dataGridView1.Rows.Clear();
            button1.Enabled = false;
            dataGridView1.Columns.Add("Column1", "Уровень");
            dataGridView1.Columns.Add("Column2", "Время");
            dataGridView1.Columns.Add("Column3", "Число ошибок");
            LoadData();

        }
    }
}
