﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace keyboard_simulator
{
    public partial class Level3 : keyboard_simulator.FormLevel
    {
    
        public Level3()
        {
            InitializeComponent();
            str1 = new String[12]
           {
            "мс ьь .. мм ьь ..",
            ".ь м .ь м .ь м .ь м .ь м",
            "м.мм м..ь мь.м ..ьм",
            "фь.в к.мм помк ь.шь",
            "пажг .аам ожфл амшж",
            "лдфо оолд ыыоы аоав",
            "уу кк гг шш фф ыы вв аа",
            "пп рр оо лл дд жж мм ьь",
            "ук гш фа пр ол дж мь",
            "уьдг ыфшв влаг ввьп",
            "ожгв ауьр ьгдп выав",
            "оьдк кыфф джьв гаьп"
           };

        }
    }
 }

