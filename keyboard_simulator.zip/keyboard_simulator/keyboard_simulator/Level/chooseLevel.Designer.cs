﻿namespace keyboard_simulator
{
    partial class chooseLevel
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelStart = new Panel();
            resultat = new Button();
            ButtonLevel3 = new Button();
            ButtonLevel2 = new Button();
            ButtonLevel1 = new Button();
            label2 = new Label();
            label1 = new Label();
            panelStart.SuspendLayout();
            SuspendLayout();
            // 
            // panelStart
            // 
            panelStart.BackColor = Color.FromArgb(128, 255, 128);
            panelStart.Controls.Add(resultat);
            panelStart.Controls.Add(ButtonLevel3);
            panelStart.Controls.Add(ButtonLevel2);
            panelStart.Controls.Add(ButtonLevel1);
            panelStart.Controls.Add(label2);
            panelStart.Controls.Add(label1);
            panelStart.Dock = DockStyle.Fill;
            panelStart.Location = new Point(0, 0);
            panelStart.Name = "panelStart";
            panelStart.Size = new Size(751, 296);
            panelStart.TabIndex = 0;
            // 
            // resultat
            // 
            resultat.BackColor = Color.Lime;
            resultat.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            resultat.ForeColor = Color.White;
            resultat.Location = new Point(233, 240);
            resultat.Name = "resultat";
            resultat.Size = new Size(295, 44);
            resultat.TabIndex = 5;
            resultat.Text = "Мой прогресс";
            resultat.UseVisualStyleBackColor = false;
            resultat.Click += resultat_Click;
            // 
            // ButtonLevel3
            // 
            ButtonLevel3.BackColor = Color.Lime;
            ButtonLevel3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonLevel3.ForeColor = Color.White;
            ButtonLevel3.Location = new Point(291, 179);
            ButtonLevel3.Name = "ButtonLevel3";
            ButtonLevel3.Size = new Size(175, 44);
            ButtonLevel3.TabIndex = 4;
            ButtonLevel3.Text = "3 Уровень";
            ButtonLevel3.UseVisualStyleBackColor = false;
            ButtonLevel3.Click += ButtonLevel3_Click;
            // 
            // ButtonLevel2
            // 
            ButtonLevel2.BackColor = Color.Lime;
            ButtonLevel2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonLevel2.ForeColor = Color.White;
            ButtonLevel2.Location = new Point(291, 129);
            ButtonLevel2.Name = "ButtonLevel2";
            ButtonLevel2.Size = new Size(175, 44);
            ButtonLevel2.TabIndex = 3;
            ButtonLevel2.Text = "2 Уровень";
            ButtonLevel2.UseVisualStyleBackColor = false;
            ButtonLevel2.Click += ButtonLevel2_Click;
            // 
            // ButtonLevel1
            // 
            ButtonLevel1.BackColor = Color.Lime;
            ButtonLevel1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonLevel1.ForeColor = Color.White;
            ButtonLevel1.Location = new Point(291, 79);
            ButtonLevel1.Name = "ButtonLevel1";
            ButtonLevel1.Size = new Size(175, 44);
            ButtonLevel1.TabIndex = 2;
            ButtonLevel1.Text = "1 Уровень";
            ButtonLevel1.UseVisualStyleBackColor = false;
            ButtonLevel1.Click += ButtonLevel1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.HotPink;
            label2.Location = new Point(5, 79);
            label2.Name = "label2";
            label2.Size = new Size(280, 31);
            label2.TabIndex = 1;
            label2.Text = "Выберите свой уровень";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DeepPink;
            label1.Location = new Point(202, 9);
            label1.Name = "label1";
            label1.Size = new Size(361, 38);
            label1.TabIndex = 0;
            label1.Text = "Клавиатурный тренажёр";
            // 
            // chooseLevel
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(751, 296);
            Controls.Add(panelStart);
            Name = "chooseLevel";
            Text = "Form1";
            panelStart.ResumeLayout(false);
            panelStart.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelStart;
        private Button ButtonLevel3;
        private Button ButtonLevel2;
        private Button ButtonLevel1;
        private Label label2;
        private Label label1;
        private Button resultat;
    }
}