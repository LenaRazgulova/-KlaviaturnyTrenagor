﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using keyboard_simulator.Model;
using Npgsql;
namespace keyboard_simulator
{

    public partial class FormLevel : Form
    {

        public String[] str1;
        public FormLevel()
        {

            InitializeComponent();
            str1 = new String[12]
            {
            "фф ыы вв аа оо лл дд жж",
            "фы ва ол дж",
            "жд до ав ыф",
            "ыоол ылыо вафы ллаж",
            "лажд олдф лолл авфо",
            "лдфо оолд ыыоы аоав",
            "dfgh","",
            "",
            "",
            ""
            ,""

            };
        }


        int i = 0;

        void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("После ввода каждой строки нажмите на Enter");
            textLevel1.Text = str1[0];
        }
        int error = 0;
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (i < 11)
                {
                    string proverka = answerLevel1.Text;
                    int dop = str1[i].Length - proverka.Length;
                    int idx = 0;
                    for (int i = 0; i < dop; i++)
                    {
                        proverka += '-';
                    }
                    foreach (char symb in str1[i])
                    {
                        if (symb != proverka[idx])
                        {
                            error++;
                        }
                        idx++;
                    }
                    answerLevel1.Clear();
                    i++;
                    textLevel1.Text = str1[i];
                    labelError.Text = error.ToString();
                }
                else
                {
                    timer1.Enabled = false;
                    MessageBox.Show("Уровень пройден. Вы можете нажать кнопку 'Назад' и перейти к другому уровню");
                    answerLevel1.Clear();
                    textLevel1.Clear();
                    using (ProgressContext db = new ProgressContext())
                    {
                        Progress progress1 = new Progress {ur=title.Text, time_progress = t, mistakes = error };
                        db.Progress.Add(progress1);
                        db.SaveChanges();
                    }
                }
            }
        }
        int t = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;
            labelTimer.Text = t.ToString();
        }

        private void answerLevel1_TextChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
    }
}
