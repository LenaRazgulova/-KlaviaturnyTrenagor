﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace keyboard_simulator
{
    public partial class Level1 : keyboard_simulator.FormLevel
    {
        public Level1()
        {
            InitializeComponent();
            str1 = new String[12]
            { 
                "фф ыы вв аа оо лл дд жж",
                "фы ва ол дж",
                "ыоол ылыо вафы ллаж",
                "лажд олдф лолл авфо",
                "лдфо оолд ыыоы аоав",
                "пр рр пп рр",
                "ррпп рпрр ррпр ппрр",
                "Прпр рпрр рпрр прпп",
                "Фрпп рфаы рожа пдпв",
                "Фрро пжрж дрпп рппр",
                "Ппып ыпрп жрор ррпр",
                "Ппвр рдлп рдпа оыып"
            };
        }
       

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
