﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace keyboard_simulator.Model
{
    public class ProgressContext: DbContext 
    {
        public DbSet<Progress> Progress { get; set; } = null;
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=Progress;Username=postgres;password=l258i852R?");
        }
    }
}
