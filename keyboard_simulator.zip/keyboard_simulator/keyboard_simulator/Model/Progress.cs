﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keyboard_simulator.Model
{
    public class Progress
    {
        public string ur { get; set; }
        public int Id{ get; set; }
        public int time_progress { get; set;}
        public int mistakes { get; set;}
    }
}
